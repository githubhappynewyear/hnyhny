<?php 
/*
Template Name: NM_Tmpl
*/
get_header();
?>
	<div class="nm-page-header"><h2 class="nm-page-title"><?php the_title();?></h2></div>
<?php netease_music();?>
<?php get_footer(); ?>
